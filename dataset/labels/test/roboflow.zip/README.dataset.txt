# Squat > 2025-03-22 9:42pm
https://universe.roboflow.com/hop-vzah8/squat-ntxfq-rpuz2

Provided by a Roboflow user
License: CC BY 4.0

